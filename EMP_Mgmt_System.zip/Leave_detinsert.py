#Program  to insert leavedet employee table -python
import warnings
warnings.filterwarnings('ignore')
import tkinter as tk
from tkinter import *
from tkinter import messagebox
import mysql.connector as sql

#creating function to insert details 
def insert_details():
    if any ([not empty.get() for empty in [Ecode_entry,Ename_entry,L_date_entry,Reason_entry,Dcode_entry]]):
        messagebox.showerror("Error","All fields are mandatory.")
        
    #connecting database
    db_connection=sql.connect(host='localhost',database='ems',user='root',password='')
    db_cursor=db_connection.cursor()

    #Getting data from GUI
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    L_date=L_date_entry.get()
    Reason=Reason_entry.get()
    Dcode=Dcode_entry.get()

    #Query
    db_cursor.execute("insert into leave_det(Ecode,Ename,L_date,Reason,Dcode)values(%s,%s,%s,%s,%s)",[str(Ecode),str(Ename),str(L_date),str(Reason),str(Dcode)])
    messagebox.showinfo("Employee Details","Leave inserted sucessfully!")
    db_connection.commit()
    
    db_connection.close()
    #Calling a close method
    clear_details()
    
def clear_details():
    #clearing after data
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    L_date_entry.delete(0, tk.END)
    Reason_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

#Create main controls
Window=tk.Tk()
Window.title("Employee Management System")
Window.geometry("800x500+300+150")

#Declaring Controls
head=tk.Label(Window,text="Insert Leave Details",bg='green',fg="white",font='sans 17 bold')
head.grid(row=0,columnspan=5,padx=10,pady=10,sticky='nsew')

Ecode=tk.Label(Window,text="Employee Code :",font='sans 14 bold')
Ename=tk.Label(Window,text="Employee Name :",font='sans 14 bold')
L_date=tk.Label(Window,text="Leave Date :",font='sans 14 bold')
Reason=tk.Label(Window,text="Reason :",font='sans 14 bold')
Dcode=tk.Label(Window,text="Department Code:",font='sans 14 bold')

Ecode_entry=tk.Entry(Window,width=20,font='sans 18 bold')
Ename_entry=tk.Entry(Window,width=20,font='sans 18 bold')
L_date_entry=tk.Entry(Window,width=20,font='sans 18 bold')
Reason_entry=tk.Entry(Window,width=20,font='sans 18 bold')
Dcode_entry=tk.Entry(Window,width=20,font='sans 18 bold')

#Controls value grid
Ecode.grid(row=1,column=3,padx=10,pady=10)
Ename.grid(row=2,column=3,padx=10,pady=10)
L_date.grid(row=3,column=3,padx=10,pady=10)
Reason.grid(row=4,column=3,padx=10,pady=10)
Dcode.grid(row=5,column=3,padx=10,pady=10)

Ecode_entry.grid(row=1,column=4,padx=10,pady=10)
Ename_entry.grid(row=2,column=4,padx=10,pady=10)
L_date_entry.grid(row=3,column=4,padx=10,pady=10)
Reason_entry.grid(row=4,column=4,padx=10,pady=10)
Dcode_entry.grid(row=5,column=4,padx=10,pady=10)

#Creating Button for Submit,cancel,Clear
Insert_button=tk.Button(Window,text="Insert",bg="Lightgreen",fg="Black",font="sans 16 bold",command=insert_details)
Insert_button.grid(row=7,column=3)

Exit_button=tk.Button(Window,text="Exit",bg="Lightgreen",fg="Black",font="sans 16 bold",command=Window.destroy)
Exit_button.grid(row=7,column=6)

Window.mainloop()

