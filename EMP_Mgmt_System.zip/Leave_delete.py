#Program to delete data leave det  -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

#Creating function to search details 
def search_details():

    #connecting to database
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #getting data from entry box 
    Ecode=Ecode_entry.get()

    #Query 
    db_cursor.execute("select * from leave_det where Ecode=%s",[str(Ecode)])
    result=db_cursor.fetchone()

    #displaying data 
    if result:
        Ename_entry.delete(0, tk.END)
        Ename_entry.insert(tk.END,result[1])

        L_date_entry.delete(0, tk.END)
        L_date_entry.insert(tk.END,result[2])

        Reason_entry.delete(0, tk.END)
        Reason_entry.insert(tk.END,result[3])

        Dcode_entry.delete(0, tk.END)
        Dcode_entry.insert(tk.END,result[4])
    else:   
        messagebox.showinfo("Error","Employee Not Found")
    
    db_connection.close()

#creating function to delete data 
def delete_details():

    #connecting to database 
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #Data from entry box 
    Ecode=Ecode_entry.get()

    #Query
    db_cursor.execute("delete from leave_det where Ecode=%s",[str(Ecode)])

    db_connection.commit()
    db_connection.close()
    
    clear_details()

    messagebox.showinfo("Employee Details","Data Deleted Successfully!")

#Creating fucntion to clear details
def search_details():
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    L_date_entry.delete(0, tk.END)
    Reason_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

#Creating main window 
window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Deleting Leave Details",bg="green",fg="white",font="sans 17 bold")
head.grid(row=0,columnspan=4,padx=10,pady=10,sticky='nsew')

Ecode=tk.Label(window,text="Employee Code:",font='sans 14 bold')
Ecode.grid(row=1,column=1,padx=10,pady=10)
Ecode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ecode_entry.grid(row=1,column=2,padx=10,pady=10)

search_button=tk.Button(window,text="Search",bg="silver",fg="white",font="sans 14 bold",command=search_details)
search_button.grid(row=1,column=4)

Ename=tk.Label(window,text="Employee Name:",font='sans 14 bold')
Ename.grid(row=2,column=1,padx=10,pady=10)
Ename_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ename_entry.grid(row=2,column=2,padx=10,pady=10)

L_date=tk.Label(window,text="Leave Date :",font='sans 14 bold')
L_date.grid(row=3,column=1,padx=10,pady=10)
L_date_entry=tk.Entry(window,width=20,font='sans 18 bold')
L_date_entry.grid(row=3,column=2,padx=10,pady=10)

Reason=tk.Label(window,text="Reason :",font='sans 14 bold')
Reason.grid(row=4,column=1,padx=10,pady=10)
Reason_entry=tk.Entry(window,width=20,font='sans 18 bold')
Reason_entry.grid(row=4,column=2,padx=10,pady=10)

Dcode=tk.Label(window,text="Dcode:",font='sans 14 bold')
Dcode.grid(row=5,column=1,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Dcode_entry.grid(row=5,column=2,padx=10,pady=10)

delete_button=tk.Button(window,text="Delete",bg="cyan",font='sans 14 bold',command=delete_details)
delete_button.grid(row=7,column=2)

window.mainloop()

