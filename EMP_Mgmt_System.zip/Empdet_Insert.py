#program to insert Employee details-python
import warnings
warnings.filterwarnings('ignore')
import tkinter as tk
from tkinter import *
import mysql.connector as sql
from tkinter import messagebox

def insert_details():
    if any ([not entry.get() for entry in [Ecode_entry,Ename_entry,Education_entry,Experience_entry,Dcode_entry]]):
        messagebox.showerror("Error","All fields are mandatory.")
        
    #connecting database
    db_connection=sql.connect(host='localhost',database='ems',user='root',password='')
    db_cursor=db_connection.cursor()

    #Getting data from GUI
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Education=Education_entry.get()
    Experience=Experience_entry.get()
    Dcode=Ecode_entry.get()

    #Inserting data into the database
    db_cursor.execute("insert into emp_det(Ecode,Ename,Education,Experience,Dcode)values(%s,%s,%s,%s,%s)",[str(Ecode),str(Ename),str(Education),str(Experience),str(Dcode)])
    #res="Record added sucessfully!"
    #lbl=tk.Label(Window,text=res).grid(row=7,column=0)
    messagebox.showinfo("Employee Details","Data Inserted Successfully")
    db_connection.commit()
    db_connection.close()
    #Calling a close method
    clear_details()
def clear_details():
    #clearing after data
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    Education_entry.delete(0, tk.END)
    Experience_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

#Create main controls
Window=tk.Tk()
Window.title("Employee Management System")
Window.geometry("800x500+300+150")

head=tk.Label(Window,text="Insert Employee Details",bg="yellow",fg="green",font="sans 20 bold")
head.grid(row=0,column=3,columnspan=3,sticky='nsew',padx=10,pady=10)

#Declaring Controls
Ecode=tk.Label(Window,text="Employee Code :",font='sans 16 bold')
Ename=tk.Label(Window,text="Employee Name :",font='sans 16 bold')
Education=tk.Label(Window,text="Education :",font='sans 16 bold')
Experience=tk.Label(Window,text="Exprience :",font='sans 16 bold')
Dcode=tk.Label(Window,text="Department Code :",font='sans 16 bold')

Ecode_entry=tk.Entry(Window,width=20,font='snas 18 bold')
Ename_entry=tk.Entry(Window,width=20,font='snas 18 bold')
Education_entry=tk.Entry(Window,width=20,font='snas 18 bold')
Experience_entry=tk.Entry(Window,width=20,font='snas 18 bold')
Dcode_entry=tk.Entry(Window,width=20,font='snas 18 bold')

#Controls value grid
Ecode.grid(row=1,column=2,padx=10,pady=10)
Ename.grid(row=2,column=2,padx=10,pady=10)
Education.grid(row=3,column=2,padx=10,pady=10)
Experience.grid(row=4,column=2,padx=10,pady=10)
Dcode.grid(row=5,column=2,padx=10,pady=10)

Ecode_entry.grid(row=1,column=4)
Ename_entry.grid(row=2,column=4)
Education_entry.grid(row=3,column=4)
Experience_entry.grid(row=4,column=4)
Dcode_entry.grid(row=5,column=4)

#Creating Button for Submit,cancel,Clear
submit_button=tk.Button(Window,text="Submit",bg="Lightgreen",fg="Black",font='sans 16 bold',command=insert_details).grid(row=6,column=2)
cancel_button=tk.Button(Window,text="Cancel",bg="Silver",fg="red",font='sans 16 bold',command=Window.destroy).grid(row=6,column=4)
clear_button=tk.Button(Window,text="Clear",bg="cyan",font='sans 16 bold',command=clear_details).grid(row=6,column=6)

lbl=tk.Label(Window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=8,column=0,columnspan=8,sticky='nsew',padx=10,pady=10)

Window.mainloop()



































    

    

    
