#Log in form page window using GUI -python
import tkinter as tk
from tkinter import messagebox
import os
def check_login():
    entered_username = username_entry.get()
    entered_password = password_entry.get()

    if entered_username =='admin' and entered_password =='123':
        login_window.destroy()
        open_main_window()
    else:
        messagebox.showerror("Login Failed","Invalid username or password")

def open_main_window():
    main_window = tk.Tk()
    main_window.title("Main Window")
    main_window.geometry("600x200+500+300")

    def Open_Dashboard():
        main_window.destroy()
        os.system("Dasgboard") 
    

    
    #Add widgets or content to the msin window
    label = tk.Label(main_window,text="Welcome to the Main window-dashboard!",font="sans 18 bold",fg="green",bg="yellow")
    label.pack(padx=20,pady=20)
    b1=tk.Button(main_window,text="Click Here ",font="sans 14 bold",bg="red",fg="white",command=main_window.destroy).pack()
    b2=tk.Button(main_window,text="Close App",font="sans 14 bold",bg="red",fg="white",command=main_window.destroy).pack()
    
    #Start the TKinter event loop for the main window
    main_window.mainloop()

#Create the login window
login_window = tk.Tk()
login_window.title("Login")
login_window.geometry("300x300+300+100")
label=tk.Label(login_window,text="login here",font="sans 18 bold",fg="green",bg="yellow").pack(fill="both")

#Add widgets to the login window

username_label = tk.Label(login_window,text="Username:")
username_label.pack(pady=10)

username_entry = tk.Entry(login_window)
username_entry.pack(pady=10)

password_label = tk.Label(login_window,text="Password:")
password_label.pack(pady=10)

password_entry = tk.Entry(login_window,show="*")
password_entry.pack(pady=10)

login_button = tk.Button(login_window,text="Login",command=check_login)
login_button.pack(pady=20)

#Start the Tkinter event loop for the login window
login_window.mainloop()

