#Program to Update data from Emp_det -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

def search_employee():
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    Ecode=Ecode_entry.get()

    db_cursor.execute("select * from emp_sal where Ecode=%s",[str(Ecode)])
    result=db_cursor.fetchone()

    if result:
        Ename_entry.delete(0, tk.END)
        Ename_entry.insert(tk.END,result[1])

        Dcode_entry.delete(0, tk.END)
        Dcode_entry.insert(tk.END,result[2])

        Basic_entry.delete(0, tk.END)
        Basic_entry.insert(tk.END,result[3])

    db_connection.close()

def update_details():

    if any([not empty.get() for empty in(Ecode_entry,Ename_entry,Basic_entry,Dcode_entry)]):
       messagebox.showerror("Error","All fields are mandatory!")
       return

    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Dcode=Dcode_entry.get()
    Basic=float(Basic_entry.get())

    if Basic>50000:
        HRA=int(2000)       
        PF=Basic*(12/100)
    else:
        HRA=int(1000)
        PF=Basic*(8/100)

    Net_salary=float(Basic+int(HRA)-int(PF))

    #Query    
    db_cursor.execute("update emp_sal set Ename=%s,Dcode=%s,Basic_sal=%s,HRA=%s,PF=%s,Net_sal=%s where Ecode=%s",[str(Ename),str(Dcode),str(Basic),str(HRA),str(PF),str(Net_salary),str(Ecode)])
    db_connection.commit()
    db_connection.close()
    
    clear_details()
    
    messagebox.showinfo("Employee Salary","Data Updated Successfully!")

def clear_details():
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)
    Basic_entry.delete(0, tk.END)
#Calculate Function to calculate  details of employee sal 
def calculate_details():
    #db_connection=sql.connect(host="localhost",database"ems",user="root",password="")
    #db_cursor=db_connection.cursor()

    #getting data from entrybox
    Basic=float(Basic_entry.get())

    if Basic>50000:
        HRA=int(20000)
        res1=[str(HRA)]
        res1=tk.Label(window,text=res1).grid(row=5,column=1)

        PF=Basic*(12/100)
        res2=[str(PF)]
        res2=tk.Label(window,text=res2).grid(row=6,column=1)

    else:
        HRA=int(1000)
        res3=[str(HRA)]
        res3=tk.Label(window,text=res3).grid(row=5,column=1)

        PF=Basic*(8/100)
        res4=[str(PF)]
        res4=tk.Label(window,text=res4).grid(row=6,column=1)

    Net_salary=float(Basic)+int(HRA)-int(PF)
    res5=[str(Net_salary)]
    res5=tk.Label(window,text=res5).grid(row=7,column=1)

#Creating mainwindow        
window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Employee Sal Update",bg="red",fg="white",font="sans 18 bold")
head.grid(row=0,columnspan=4,sticky='nsew',padx=10,pady=10)

Ecode=tk.Label(window,text="Employee Code:",font='sans 14 bold')
Ecode.grid(row=1,column=0,padx=10,pady=10)
Ecode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ecode_entry.grid(row=1,column=1,padx=10,pady=10)

search_button=tk.Button(window,text="Search Employee",bg="green",fg="white",font="sans 14 bold",command=search_employee)
search_button.grid(row=1,column=2)

Ename=tk.Label(window,text="Employee Name:",font='sans 14 bold')
Ename.grid(row=2,column=0,padx=10,pady=10)
Ename_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ename_entry.grid(row=2,column=1,padx=10,pady=10)

Dcode=tk.Label(window,text="Dcode :",font='sans 14 bold')
Dcode.grid(row=3,column=0,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Dcode_entry.grid(row=3,column=1,padx=10,pady=10)

Basic=tk.Label(window,text="Basic :",font='sans 14 bold')
Basic.grid(row=4,column=0,padx=10,pady=10)
Basic_entry=tk.Entry(window,width=20,font='sans 18 bold')
Basic_entry.grid(row=4,column=1,padx=10,pady=10)

HRA=tk.Label(window,text="HRA :",font='sans 14 bold')
HRA.grid(row=5,column=0)

PF=tk.Label(window,text="PF :",font='sans 14 bold')
PF.grid(row=6,column=0)

Net_salary=tk.Label(window,text="Net Salary :",font='sans 14 bold')
Net_salary.grid(row=7,column=0)

cal=tk.Button(window,text="Calculate",bg="cyan",fg="black",font="sans 14 bold",command=calculate_details)
cal.grid(row=8,column=0)

insert_button=tk.Button(window,text="Update",bg="cyan",fg="black",font="sans 14 bold",command=update_details)
insert_button.grid(row=8,column=1)             

clear_button=tk.Button(window,text="Clear",bg="cyan",fg="black",font="sans 14 bold",command=clear_details)
clear_button.grid(row=8,column=2)

lbl=tk.Label(window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=9,column=0,columnspan=8,sticky='nsew',padx=10,pady=10)

window.mainloop()




