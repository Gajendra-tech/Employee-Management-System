#Program to update leave details  -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

#Creating function to search details 
def search_employee():
    #Connecting database 
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()
    
    #getting data from database 
    Ecode=Ecode_entry.get()

    #Query 
    db_cursor.execute("select * from leave_det where Ecode=%s",[str(Ecode)])
    result=db_cursor.fetchone()

    if result:
        Ename_entry.delete(0, tk.END)
        Ename_entry.insert(tk.END,result[1])

        L_date_entry.delete(0, tk.END)
        L_date_entry.insert(tk.END,result[2])

        Reason_entry.delete(0, tk.END)
        Reason_entry.insert(tk.END,result[3])

        Dcode_entry.delete(0, tk.END)
        Dcode_entry.insert(tk.END,result[4])

    db_connection.close()

#Creating Fucntion to update data 
def update_details():

    #checking EMpty Value 
    if any([not empty.get() for empty in(Ecode_entry,Ename_entry,L_date_entry,Reason_entry,Dcode_entry)]):
       messagebox.showerror("Error","All fields are mandatory!")
       return
    #Connecting Database
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #Getting data from entrybox 
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    L_date=L_date_entry.get()
    Reason=Reason_entry.get()
    Dcode=Dcode_entry.get()

    #Query
    db_cursor.execute("update leave_det set Ename=%s,L_date=%s,Reason=%s,Dcode=%s where Ecode=%s",[str(Ename),str(L_date),str(Reason),str(Dcode),str(Ecode)])                      
    db_connection.commit()
    db_connection.close()
    clear_details()
    messagebox.showinfo("Leave Details","Data Updated Successfully!")

def clear_details():
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    L_date_entry.delete(0, tk.END)
    Reason_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Update Employee Leave Details",bg="yellow",fg="green",font="sans 18 bold")
head.grid(row=0,columnspan=5)

Ecode=tk.Label(window,text="Employee Code:",font='sans 14 bold')
Ecode.grid(row=1,column=1,padx=10,pady=10)
Ecode_entry=tk.Entry(window,width=20,font='sans 17 bold')
Ecode_entry.grid(row=1,column=2,padx=10,pady=10)

search_button=tk.Button(window,text="Search Employee",bg="Silver",fg="white",font='sans 12 bold',command=search_employee)
search_button.grid(row=1,column=3)

Ename=tk.Label(window,text="Employee Name:",font='sans 14 bold')
Ename.grid(row=2,column=1,padx=10,pady=10)
Ename_entry=tk.Entry(window,width=20,font='sans 17 bold')
Ename_entry.grid(row=2,column=2,padx=10,pady=10)

L_date=tk.Label(window,text="L_date :",font='sans 14 bold')
L_date.grid(row=3,column=1,padx=10,pady=10)
L_date_entry=tk.Entry(window,width=20,font='sans 17 bold')
L_date_entry.grid(row=3,column=2,padx=10,pady=10)

Reason=tk.Label(window,text="Reason :",font='sans 14 bold')
Reason.grid(row=4,column=1,padx=10,pady=10)
Reason_entry=tk.Entry(window,width=20,font='sans 17 bold')
Reason_entry.grid(row=4,column=2,padx=10,pady=10)

Dcode=tk.Label(window,text="Dcode:",font='sans 14 bold')
Dcode.grid(row=5,column=1,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font='sans 17 bold')
Dcode_entry.grid(row=5,column=2,padx=10,pady=10)

update_button=tk.Button(window,text="Update Employee",bg="Lightgreen",fg="Black",font='sans 14 bold',command=update_details)
update_button.grid(row=8,column=2)

window.mainloop()
