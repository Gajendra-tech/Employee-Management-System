#Program to Update data from Emp_det -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

def search_employee():
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    Ecode=Ecode_entry.get()

    db_cursor.execute("select * from emp_det where Ecode=%s",[str(Ecode)])
    result=db_cursor.fetchone()

    if result:
        Ename_entry.delete(0, tk.END)
        Ename_entry.insert(tk.END,result[1])

        Education_entry.delete(0, tk.END)
        Education_entry.insert(tk.END,result[2])

        Experience_entry.delete(0, tk.END)
        Experience_entry.insert(tk.END,result[3])

        Dcode_entry.delete(0, tk.END)
        Dcode_entry.insert(tk.END,result[4])

    db_connection.close()

def update_employee():

    if any([not empty.get() for empty in(Ecode_entry,Ename_entry,Education_entry,Experience_entry,Dcode_entry)]):
       messagebox.showerror("Error","All fields are mandatory!")
       return

    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Education=Education_entry.get()
    Experience=Experience_entry.get()
    Dcode=Dcode_entry.get()

    db_cursor.execute("update emp_det set Ename=%s,Education=%s,Experience=%s,Dcode=%s where Ecode=%s",[str(Ename),str(Education),str(Experience),str(Dcode),str(Ecode)])
    db_connection.commit()
    db_connection.close()
    clear_details()
    messagebox.showinfo("Employee Details","Data Updated Successfully!")

def clear_details():
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    Education_entry.delete(0, tk.END)
    Experience_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Update Employee Details",bg="yellow",fg="green",font="sans 18 bold")
head.grid(row=0,columnspan=5,sticky='nsew',padx=10,pady=10)

Ecode=tk.Label(window,text="Employee Code:",font='sans 14 bold')
Ecode.grid(row=1,column=2,padx=10,pady=10)
Ecode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ecode_entry.grid(row=1,column=3,padx=10,pady=10)

search_button=tk.Button(window,text="Search Employee",bg="Silver",fg="red",font='sans 12 bold',command=search_employee)
search_button.grid(row=1,column=4)

Ename=tk.Label(window,text="Employee Name:",font='sans 14 bold')
Ename.grid(row=2,column=2,padx=10,pady=10)
Ename_entry=tk.Entry(window,width=20,font='sans 18 bold')
Ename_entry.grid(row=2,column=3,padx=10,pady=10)

Education=tk.Label(window,text="Education:",font='sans 14 bold')
Education.grid(row=3,column=2,padx=10,pady=10)
Education_entry=tk.Entry(window,width=20,font='sans 18 bold')
Education_entry.grid(row=3,column=3,padx=10,pady=10)

Experience=tk.Label(window,text="Experience:",font='sans 14 bold')
Experience.grid(row=4,column=2,padx=10,pady=10)
Experience_entry=tk.Entry(window,width=20,font='sans 18 bold')
Experience_entry.grid(row=4,column=3,padx=10,pady=10)

Dcode=tk.Label(window,text="Dcode:",font='sans 14 bold')
Dcode.grid(row=5,column=2,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font='sans 18 bold')
Dcode_entry.grid(row=5,column=3,padx=10,pady=10)

update_button=tk.Button(window,text="Update Employee",bg="Lightgreen",fg="Black",font='sans 14 bold',command=update_employee)
update_button.grid(row=7,column=2)

update_button=tk.Button(window,text="Clear",bg="cyan",font='sans 14 bold',command=update_employee)
update_button.grid(row=7,column=3)

lbl=tk.Label(window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=8,column=0,columnspan=8,sticky='nsew',padx=10,pady=10)

window.mainloop()
                        
                        











            

    
    




    

    
    







