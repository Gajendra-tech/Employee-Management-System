import warnings
warnings.filterwarnings('ignore')
import tkinter as tk
from tkinter import *
import mysql.connector as sql
from tkinter import  messagebox 
def insert_details():
    if any ([not entry.get() for entry in [Ecode_entry,Ename_entry,Dcode_entry,Basic_entry]]):
        messagebox.showerror("Error","All fields are mandatory.")
        return
    
    #connecting database
    db_connection=sql.connect(host='localhost',database='ems',user='root',password='')
    db_cursor=db_connection.cursor()

    #Getting data from GUI
    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Dcode=Dcode_entry.get()
    Basic=float(Basic_entry.get())
    if Basic>50000:
        PF=Basic*(12/100)
    else:
        HRA=int(1000)
        PF=Basic*(8/100)

    Net_salary=float(Basic+int(HRA)-int(PF))
     
    #Inserting data into the database
    db_cursor.execute("insert into emp_sal(Ecode,Ename,Dcode,Basic_sal,HRA,PF,Net_sal)values(%s,%s,%s,%s,%s,%s,%s)",[str(Ecode),str(Ename),str(Dcode),str(Basic),str(HRA),str(PF),str(Net_salary)])
    messagebox.showinfo("Employee salary","Record added sucessfully!")
    db_connection.commit()
    db_connection.close()
    #Calling a close method
    clear_details()
                     
def clear_details():
    #clearing after data
    Ecode_entry.delete(0, tk.END)
    Ename_entry.delete(0, tk.END)
    Basic_entry.delete(0, tk.END)
    Dcode_entry.delete(0, tk.END)

def calculate_details():
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    Ecode=Ecode_entry.get()
    Ename=Ename_entry.get()
    Dcode=Dcode_entry.get()
    Basic=float(Basic_entry.get())

    if Basic>50000:
        HRA=int(2000)
        res1=[str(HRA)]
        res1=tk.Label(Window,text=res1).grid(row=5,column=1)

        PF=Basic*(12/100)
        res2=[str(PF)]
        res2=tk.Label(Window,text=res2).grid(row=6,column=1)        
                
    else:
        HRA=int(1000)
        res3=[str(HRA)]
        res3=tk.Label(Window,text=res3).grid(row=5,column=1)

        PF=Basic*(8/100)
        res4=[str(PF)]
        res4=tk.Label(Window,text=res4).grid(row=6,column=1)            
                
    Net_salary=float(Basic+int(HRA)-int(PF))
    res5=[str(Net_salary)]                 
    res5=tk.Label(Window,text=res5).grid(row=7,column=1)                 

#Create main controls
Window=tk.Tk()
Window.title("Employee Management System")
Window.geometry("800x500+300+150")

head=tk.Label(Window,text="Employee Sal insert",bg="green",fg="white",font="sans 18 bold")
head.grid(row=0,columnspan=5,sticky='nsew',padx=10,pady=10)

#Declaring Controls
Ecode=tk.Label(Window,text="Employee Code :",font='sans 16 bold')
Ename=tk.Label(Window,text="Employee Name :",font='sans 16 bold')
Basic=tk.Label(Window,text="Basic Salary :",font='sans 16 bold')
Dcode=tk.Label(Window,text="Department Code :",font='sans 16 bold')

Ecode_entry=tk.Entry(Window,width=20,font="sans 18 bold")
Ename_entry=tk.Entry(Window,width=20,font="sans 18 bold")
Basic_entry=tk.Entry(Window,width=20,font="sans 18 bold")
Dcode_entry=tk.Entry(Window,width=20,font="sans 18 bold")

#Controls value grid
Ecode.grid(row=2,column=0,padx=10,pady=10)
Ename.grid(row=3,column=0,padx=10,pady=10)
Basic.grid(row=4,column=0,padx=10,pady=10)
Dcode.grid(row=5,column=0,padx=10,pady=10)

Ecode_entry.grid(row=2,column=1,padx=10,pady=10)
Ename_entry.grid(row=3,column=1,padx=10,pady=10)
Basic_entry.grid(row=4,column=1,padx=10,pady=10)
Dcode_entry.grid(row=5,column=1,padx=10,pady=10)

HRA=tk.Label(Window,text="HRA :",font="sans 14 bold")
HRA.grid(row=6,column=0)

PF=tk.Label(Window,text="PF :",font="sans 14 bold")
PF.grid(row=8,column=0)

Net_salary=tk.Label(Window,text="Net Salary :",font="sans 14 bold")
Net_salary.grid(row=10,column=0)

cal=tk.Button(Window,text="Calculate",bg="cyan",fg="white",font="sans 16 bold",command=calculate_details)
cal.grid(row=11,column=0)

insert_button=tk.Button(Window,text="Insert",bg="cyan",fg="white",font="sans 16 bold",command=insert_details)
insert_button.grid(row=11,column=1)             

clear_button=tk.Button(Window,text="Clear",bg="cyan",fg="white",font="sans 16 bold",command=clear_details)
clear_button.grid(row=11,column=3)

lbl=tk.Label(Window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=13,column=0,columnspan=4,sticky='nsew',padx=10,pady=10)
             
Window.mainloop()
