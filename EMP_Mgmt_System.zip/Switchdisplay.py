import tkinter as tk
from tkinter import ttk
import mysql.connector as sql

#creating function to fetch data
def fetch_data():
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    db_cursor.execute("select * from emp_det")
    data=db_cursor.fetchall()
    db_connection.close()
    return data

#Searching fucntion  to display data
def display_data():
    data=fetch_data()

    for row in tree.get_children():
        tree.detele(row)

    #inserting into tree view
    for record in data:
        tree.insert("","end",values=record)
        
#creating main window 
window=tk.Tk()
window.title("Employee Management System")
window.geometry("1000x500+200+150")

#creating a tree view for displaying data
columns=("Ecode","Ename","Education","Experience","Dcode")
tree=ttk.Treeview(window,columns=columns,show="headings")

#set up column headings
for col in columns:
    tree.heading(col,text=col)
    
head=tk.Label(window,text="Display Employee Details",bg="yellow",fg="green",font="sans 18 bold")
head.grid(row=0,columnspan=5)

tree.grid(row=1,column=0,padx=10,pady=10)

#creating Show button details
show_button=ttk.Button(window,text="Show details",command=display_data)
show_button.grid(row=2,column=0,pady=10)

exit_button=ttk.Button(window,text="Exit Details",command=display_data)
exit_button.grid(row=3,column=0,pady=10)
window.mainloop()
    
        
         

        













    
