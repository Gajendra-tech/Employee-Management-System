#Program to update Deprt details  -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

#Creating function to search details 
def search_details():
    #Connecting database 
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()
    
    #getting data from database 
    Dcode=Dcode_entry.get()

    #Query 
    db_cursor.execute("select * from dept_det where Dcode=%s",[str(Dcode)])
    result=db_cursor.fetchone()

    if result:
        Dname_entry.delete(0, tk.END)
        Dname_entry.insert(tk.END,result[1])

        Dlocation_entry.delete(0, tk.END)
        Dlocation_entry.insert(tk.END,result[2])

    db_connection.close()

#Creating Fucntion to update data 
def update_details():

    #checking EMpty Value 
    if any([not empty.get() for empty in(Dcode_entry,Dname_entry,Dlocation_entry)]):
       messagebox.showerror("Error","All fields are mandatory!")
       return
    #Connecting Database
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #Getting data from entrybox 
    Dcode=Dcode_entry.get()
    Dname=Dname_entry.get()
    Dlocation=Dlocation_entry.get()

    #Query
    db_cursor.execute("update dept_det set Dname=%s,Dlocation=%s where Dcode=%s",[str(Dname),str(Dlocation),str(Dcode)])                      
    db_connection.commit()
    db_connection.close()
    clear_details()
    messagebox.showinfo("Department Details","Data Updated Successfully!")

def clear_details():
    Dcode_entry.delete(0, tk.END)
    Dname_entry.delete(0, tk.END)
    Dlocation_entry.delete(0, tk.END)

window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Update Department Deatails",bg="green",fg="white",font="Sans 18 bold")
head.grid(row=0,columnspan=3,sticky='nsew',padx=10,pady=10)

Dcode=tk.Label(window,text="Department Code:",font='sans 14 bold')
Dcode.grid(row=1,column=1,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dcode_entry.grid(row=1,column=2,padx=10,pady=10)

search_button=tk.Button(window,text="Search",bg="cyan",fg="black",font="sans 14 bold",command=search_details)
search_button.grid(row=1,column=3)

Dname=tk.Label(window,text="Department Name:",font='sans 14 bold')
Dname.grid(row=2,column=1,padx=10,pady=10)
Dname_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dname_entry.grid(row=2,column=2,padx=10,pady=10)

Dlocation=tk.Label(window,text="Department location :",font='sans 14 bold')
Dlocation.grid(row=3,column=1,padx=10,pady=10)
Dlocation_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dlocation_entry.grid(row=3,column=2,padx=10,pady=10)

update_button=tk.Button(window,text="Update ",bg="cyan",fg="black",font="sans 14 bold",command=update_details)
update_button.grid(row=7,columnspan=3)

lbl=tk.Label(window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=8,column=0,columnspan=8,sticky='nsew',padx=10,pady=10)

window.mainloop()

