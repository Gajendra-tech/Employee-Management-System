#Proggram to Dashboard for Employee -python
import tkinter as tk
from tkinter import ttk
from PIL import Image,ImageTk
import os
import time

class Dashboard(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Employee Project Dashboard")
        self.geometry("1360x740")

        #Load and Display image
        self.load_image("EMP.webp")

        #Create menu
        self.menu=tk.Menu(self)
        self.config(menu=self.menu)

        #Create Employee Details menu 
        self.emp_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Employee Details", menu=self.emp_menu)
        self.emp_menu.add_command(label="Insert", command=self.Open_Emp_det_insert)
        self.emp_menu.add_command(label="Update", command=self.Open_EMp_UPDATE)
        self.emp_menu.add_command(label="Delete", command=self.Open_Empdetdelete)
        self.emp_menu.add_command(label="All Employe Details", command=self.Open_Switchdisplay)
        self.emp_menu.add_separator()
        self.emp_menu.add_command(label="Exit", command=self.destroy)

        #Create Leave details menu
        self.leave_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Leave Details", menu=self.leave_menu)
        self.leave_menu.add_command(label="Insert", command=self.Open_Leave_detinsert)
        self.leave_menu.add_command(label="Update", command=self.Open_Leave_Update)
        self.leave_menu.add_command(label="Delete", command=self.Open_Leave_delete)
        self.leave_menu.add_command(label="All Employe Details", command=self.Open_Leave_display)
        self.leave_menu.add_separator()
        self.leave_menu.add_command(label="Exit", command=self.destroy)

        #Create Department Details menu
        self.dept_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Department Details", menu=self.dept_menu)
        self.dept_menu.add_command(label="Insert", command=self.Open_Dept_insert)
        self.dept_menu.add_command(label="Update", command=self.Open_Dept_update)
        self.dept_menu.add_command(label="Delete", command=self.Open_Dept_delete)
        self.dept_menu.add_command(label="All Employe Details", command=self.Open_Dept_Display)
        self.dept_menu.add_separator()
        self.dept_menu.add_command(label="Exit", command=self.destroy)

        #Create Employee Salary Details 
        self.sal_menu=tk.Menu(self.menu, tearoff=0)
        self.menu.add_cascade(label="Employee Salary Details", menu=self.sal_menu)
        self.sal_menu.add_command(label="Insert", command=self.Open_Emp_sal_insert)
        self.sal_menu.add_command(label="Update", command=self.Open_Emp_sal_update)
        self.sal_menu.add_command(label="Delete", command=self.Open_Emp_sal_delete)
        self.sal_menu.add_command(label="All Employe Details", command=self.Open_Emp_sal_Display)
        self.sal_menu.add_separator()
        self.sal_menu.add_command(label="Exit", command=self.destroy)

    def load_image(self, image_path):
        image=Image.open(image_path)
        image=image.resize((800,500))
        self.dashboard_image= ImageTk.PhotoImage(image)
        self.image_label =tk.Label(self , image=self.dashboard_image)
        hd=tk.Label(self,text="Employee Management System", bg="orange", fg="green",font="Sans 16 bold").pack(fill="both")
        self.image_label.pack()
        sd=tk.Label(self,text="Developed by GAJENDRA REDDY", bg="green",fg="white",font="sans 14 bold").pack(fill="both")

        #Show time
        self.time_label=tk.Label(self, text="",font=("Helvetica", 12),bg="yellow")
        self.time_label.pack(pady=10,side="right")
        self.update_time()
        
    def update_time(self):
        current_time=time.strftime("$H:%M:%S")
        self.time_label.config(text=current_time)
        self.after(1000, self.update_time)

       #Employee details   
    def Open_Emp_det_insert(self):
        #exsting file
        #os.system("Empdet_Insert.py")
        import Empdet_Insert as E
        
    def Open_EMp_UPDATE(self):
        #exsting file
        #os.system("EMp_UPDATE.py")
        import EMpdet_UPDATE as U
        
    def Open_Empdetdelete(self):
        #exsting file
        #os.system("Empdetdelete.py")
        import Empdetdelete as D
        
    def Open_Switchdisplay(self):
        #exsting file
        #os.system("Switchdisplay.py")
        import Switchdisplay as Dis
        
       #Leave Details 
    def Open_Leave_detinsert(self):
        #exsting file
        #os.system("Leave_detinsert.py")
        import Leave_detinsert as L
        
    def Open_Leave_Update(self):
        #exsting file
        #os.system("Leave_Update.py")
        import Leave_Update as up
        
    def Open_Leave_delete(self):
        #exsting file
        #os.system("Leave_delete.py")
        import Leave_delete as de
        
    def Open_Leave_display(self):
        #exsting file
        #os.system("Leave_display.py")
        import Leave__display as dis
        
   #Department Details 
    def Open_Dept_insert(self):
        #exsting file
        #os.system("Dept_insert.py")
        import Dept_insert as I
        
    def Open_Dept_update(self):
        #exsting file
        #os.system("Dept_update.py")
        import Dept_Update as up
        
    def Open_Dept_delete(self):
        #exsting file
        #os.system("Dept_delete.py")
        import Dept_Delete as de
        
    def Open_Dept_Display(self):
        #exsting file
        #os.system("Dept_Display.py")
        import Dept_Display as dis

        #Employee sal details   
    def Open_Emp_sal_insert(self):
        #exsting file
        #os.system("Emp_sal_insert.py")
        import Emp_sal_insert as sal 

    def Open_Emp_sal_update(self):
        #exsting file
        #os.system("Emp_sal_update.py")
        import Emp_sal_update as Sal  

    def Open_Emp_sal_delete(self):
        #exsting file
        #os.system("Emp_sal_delete.py")
        import Emp_sal_delete as sal 
        
    def Open_Emp_sal_Display(self):
        #exsting file
        #os.system("Emp_Sal_Display.py")
        import Emp_sal_Display as sal 
        
if __name__=="__main__":
    app = Dashboard()
    app.mainloop()

