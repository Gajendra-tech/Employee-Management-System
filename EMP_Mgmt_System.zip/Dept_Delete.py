#Program to delete data Departmrnt details  -python
import tkinter as tk
from tkinter import messagebox
import mysql.connector as sql

#Creating function to search details 
def search_details():

    #connecting to database
    db_connection = sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #getting data from entry box 
    Dcode=Dcode_entry.get()

    #Query 
    db_cursor.execute("select * from dept_det where Dcode=%s",[str(Dcode)])
    result=db_cursor.fetchone()

    #displaying data 
    if result:
        Dname_entry.delete(0, tk.END)
        Dname_entry.insert(tk.END,result[1])

        Dlocation_entry.delete(0, tk.END)
        Dlocation_entry.insert(tk.END,result[2])
        
    else:   
        messagebox.showinfo("Error","Department Code Not Found")
    
    db_connection.close()

#creating function to delete data 
def delete_details():
    if any([not entry.get() for entry in(Dcode_entry,Dlocation_entry)]):
        messagebox.showerror("Error","All fields Are Mandatory")
        return

    
    #connecting to database 
    db_connection=sql.connect(host="localhost",database="ems",user="root",password="")
    db_cursor=db_connection.cursor()

    #Data from entry box 
    Dcode=Dcode_entry.get()

    #Query
    db_cursor.execute("delete from dept_det where Dcode=%s",[str(Dcode)])

    db_connection.commit()
    db_connection.close()    
    clear_details()

    messagebox.showinfo("Department Details","Data Deleted Successfully!")

#Creating fucntion to clear details
def clear_details():
    Dcode_entry.delete(0, tk.END)
    Dname_entry.delete(0, tk.END)
    Dlocation_entry.delete(0, tk.END)

#Creating main window 
window=tk.Tk()
window.title("Employee Management System")
window.geometry("800x500+300+150")

head=tk.Label(window,text="Deleting Leave Details",bg="green",fg="white",font="sans 18 bold")
head.grid(row=0,columnspan=3,sticky='nsew',padx=10,pady=10)

Dcode=tk.Label(window,text="Department Code:",font='sans 14 bold')
Dcode.grid(row=1,column=1,padx=10,pady=10)
Dcode_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dcode_entry.grid(row=1,column=2,padx=10,pady=10)

search_button=tk.Button(window,text="Search",bg="cyan",fg="black",font="sans 14 bold",command=search_details)
search_button.grid(row=1,column=4)

Dname=tk.Label(window,text="Department Name:",font='sans 14 bold')
Dname.grid(row=2,column=1,padx=10,pady=10)
Dname_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dname_entry.grid(row=2,column=2,padx=10,pady=10)

Dlocation=tk.Label(window,text="Department Location :",font='sans 14 bold')
Dlocation.grid(row=3,column=1,padx=10,pady=10)
Dlocation_entry=tk.Entry(window,width=20,font="sans 18 bold")
Dlocation_entry.grid(row=3,column=2,padx=10,pady=10)

delete_button=tk.Button(window,text="Delete",bg="cyan",fg="black",font="sans 14 bold",command=delete_details)
delete_button.grid(row=5,columnspan=2)

Exit_button=tk.Button(window,text="Exit",bg="cyan",fg="black",font="sans 14 bold",command=window.destroy)
Exit_button.grid(row=5,columnspan=4)

lbl=tk.Label(window,text="Employee Management System",font='sans 18 bold',bg='skyblue')
lbl.grid(row=8,column=0,columnspan=8,sticky='nsew',padx=10,pady=10)

window.mainloop()
