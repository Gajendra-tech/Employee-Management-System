#Search and edit /update record Python &My sql
import mysql.connector
import tkinter as tk
from tkinter import messagebox

def search_records():
    value_to_search = search_entry.get()
    
    query = f"Select * from emp_det where Ecode =%s"
    cursor.execute(query,(value_to_search,))
    record=cursor.fetchone()

    if record:
        for i in range(5):
            result_text_boxes[i].delete(0,tk.END)
            result_text_boxes[i].insert(0,record[i])
    else:
        messagebox.showinfo("No Record Found","No record found matching the search criteria.")

def update_record ():
    new_values=[result_text_boxes[i].get() for i in range (5)]
    condition_value = search_entry.get()

    query=f"UPDATE EMP DET"
    query=f"Ecode =%s,"
    query=f"Ename =%s,"
    query=f"Education =%s,"
    query=f"Experience=%s,"
    query=f"Dcode =%s,"

    cursor.execute(query,(*new_values,condition_value))
    connection.commit()
    messagebox.showinfo("Record Updated","Record Updated Sucsessfully.")

#Connect to MySQL
connection=mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="ems")

#Create cursor for connection
cursor=connection.cursor()

#Create GUI form
root=tk.Tk()
root.title("Search,Update and Display Records")

search_label = tk.Label(root,text="Search Value:")
search_label.grid(row=0, column=0)
search_entry = tk.Entry(root)
search_entry.grid(row=0, column=1)

search_button=tk.Button(root,text="Search", command=search_records)
search_button.grid(row=0,column=2,padx=4,pady=3)

table_var=tk.StringVar(root)
table_var.set("emp_det")
table_label=tk.Label(root, text="Emp_det:")
table_entry=tk.Entry(root, textvariable=table_var)

search_column_var = tk.StringVar(root)
search_column_var.set("Ecode")
search_column__label = tk.Label(root,text="Search column:")

result_text_boxes=[]
for i in range(5):
   result_text_label = tk.Label(root,text=f"Column{i+1}:")
   result_text_label.grid(row=i+2, column=0)
   result_text_box = tk.Entry(root)
   result_text_box.grid(row=i+2,column=1, columnspan=2)
   result_text_boxes.append(result_text_box)
   
update_frame = tk.Frame(root)
update_frame.grid(row=6, column=0, columnspan=4)

update_column_var = tk.StringVar(root)
update_column2_var = tk.StringVar(root)
update_column3_var = tk.StringVar(root)
update_column4_var = tk.StringVar(root)
update_column5_var = tk.StringVar(root)

update_button = tk.Button(root,text="Update Record", command=update_record)
update_button.grid(row=7, column=0, columnspan=4)

root.mainloop()

#Close cursor and Connection Object
cursor.close()
connection.close()





















                         







    
    
